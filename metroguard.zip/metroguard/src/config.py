"""Central constants for MetroGuard. No magic numbers elsewhere."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "model"
DB_DIR = ROOT / "database"

ASSETS_CSV = DATA_DIR / "assets.csv"
FAULTS_CSV = DATA_DIR / "fault_logs.csv"
MAINT_CSV = DATA_DIR / "maintenance_logs.csv"
META_JSON = DATA_DIR / "meta.json"
MODEL_PATH = MODEL_DIR / "failure_model.pkl"
DB_PATH = DB_DIR / "metroguard.db"

SEED = 42

# ---- Fleet / data generation -------------------------------------------------
HISTORY_DAYS = 730
START_DATE = "2023-07-01"  # history start; "today" = START_DATE + HISTORY_DAYS
STATIONS = [
    "Motera", "Stadium", "Vastrapur", "Thaltej", "Gurukul Road",
    "Gujarat University", "Ranip", "Old High Court", "Sabarmati", "Chandkheda",
]
MANUFACTURERS = ["Alstom-Syn", "KoneTech", "SchinX", "HitaLift", "AFC-Systems", "MetroVend"]

ASSET_TYPES = {
    # type: (prefix, count, interval_days, maint_minutes range, fault types)
    "Escalator": ("ESC", 200, 30, (40, 90),
                  ["Motor", "Brake", "Electrical", "Mechanical", "Overheating", "Sensor"]),
    "Lift": ("LIFT", 150, 45, (35, 80),
             ["Door", "Motor", "Electrical", "Sensor", "Brake", "Communication"]),
    "TicketGate": ("AFC", 400, 60, (20, 45),
                   ["Sensor", "CardReader", "Door", "Communication", "Electrical", "Mechanical"]),
    "TicketMachine": ("TVM", 150, 60, (20, 40),
                      ["CardReader", "Display", "Communication", "Electrical", "Mechanical"]),
}
ALL_FAULT_TYPES = ["Motor", "Brake", "Door", "Sensor", "Electrical",
                   "Communication", "CardReader", "Display", "Mechanical", "Overheating"]
MAINTENANCE_TYPES = ["Preventive", "Corrective", "Inspection"]
TECHNICIAN_COUNT = 24

# ---- Features / model --------------------------------------------------------
NEVER_DAYS = 400  # sentinel for "never faulted / never serviced"
TREND_WINDOW_DAYS = 15
PREDICTION_HORIZON_DAYS = 7
SNAPSHOT_STEP_DAYS = 7
WARMUP_DAYS = 120  # skip earliest snapshots (no history yet)
VALIDATION_FRACTION_DAYS = 120  # last N days held out for validation
ASSET_TYPE_LEVELS = ["Escalator", "Lift", "TicketGate", "TicketMachine"]

FEATURE_COLUMNS = [
    "asset_age_years", "fault_count_7d", "fault_count_30d", "fault_count_90d",
    "average_downtime_30d", "total_downtime_30d", "max_severity_30d",
    "average_repair_time_30d", "days_since_last_fault", "days_since_last_maintenance",
    "maintenance_overdue_days", "previous_failure_count", "fault_frequency_trend",
    "downtime_trend", "criticality", "maintenance_interval_days",
    "type_Escalator", "type_Lift", "type_TicketGate", "type_TicketMachine",
]
HIGH_SEVERITY = 4  # severity >= this triggers a corrective visit in the data generator
FAILURE_MIN_SEVERITY = 3  # a fault with severity >= this counts as a "failure" (target + history)
PREVIOUS_FAILURE_DAYS = 365

# ---- Risk engine -------------------------------------------------------------
W_ML, W_CRIT, W_TREND, W_OVERDUE = 0.70, 0.10, 0.10, 0.10
ML_PROB_SCALE = 0.6   # probability at/above this maps to ML component = 1.0
TREND_SCALE = 4.0     # fault-count increase (15d vs previous 15d) mapped to 1.0
OVERDUE_SCALE_DAYS = 30.0
RISK_BANDS = [(90, "CRITICAL"), (75, "HIGH"), (50, "MEDIUM"), (25, "LOW"), (0, "NORMAL")]
PREDICTED_FAILURE_THRESHOLD = 0.35  # probability threshold for predicted class (base rate ~0.12)
CATEGORY_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]
CATEGORY_COLORS = {"CRITICAL": "#b42318", "HIGH": "#e8590c", "MEDIUM": "#f0b429",
                   "LOW": "#4f9d69", "NORMAL": "#98a2b3"}

# ---- Scheduler ---------------------------------------------------------------
DEFAULT_WINDOW_START = "22:00"
DEFAULT_WINDOW_END = "05:00"
DEFAULT_TEAMS = ["Team A", "Team B", "Team C"]
TRANSFER_BUFFER_MIN = 5
DEFAULT_MIN_RISK = 50.0
DEFAULT_MAX_JOBS = 40

# ---- Explanations ------------------------------------------------------------
LABEL_PROTOTYPE = "Prototype recommendation — technician validation required."
DEMO_ASSETS = ["ESC-104", "LIFT-027", "AFC-381"]

# ---- Impact estimate (ILLUSTRATIVE ASSUMPTIONS, not real metro costs) ----------
UNPLANNED_FAILURE_COST_INR = {  # emergency repair + lost service/revenue per failure
    "Escalator": 60000, "Lift": 80000, "TicketGate": 25000, "TicketMachine": 20000,
}
DEFAULT_PREVENTION_RATE = 0.50     # share of predicted failures avoided by a planned visit
DEFAULT_LABOUR_RATE_INR_HR = 2000  # crew cost per hour for a planned night job
