"""Illustrative savings estimate for a night-shift roster.

Expected failures avoided for a job = ML failure probability x prevention rate.
Avoided cost = expected failures avoided x assumed unplanned-failure cost for the asset type.
Planned cost = job duration x crew labour rate.

All cost inputs are ASSUMPTIONS for demonstration (synthetic data), not real metro figures.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

from . import config as C

MINUTES_PER_HOUR = 60


def estimate_impact(roster: pd.DataFrame, pred: pd.DataFrame, data: dict[str, Any],
                    prevention_rate: float = C.DEFAULT_PREVENTION_RATE,
                    labour_rate_hr: float = C.DEFAULT_LABOUR_RATE_INR_HR) -> dict[str, float]:
    """Return expected failures avoided, downtime avoided (hours), costs and net saving."""
    if roster.empty:
        return dict(failures_avoided=0.0, downtime_hours=0.0, avoided_cost=0.0,
                    planned_cost=0.0, net_saving=0.0, roi=0.0)
    jobs = roster.merge(pred[["asset_id", "ml_probability"]], on="asset_id")
    avg_downtime = (data["faults"].merge(data["assets"][["asset_id", "asset_type"]], on="asset_id")
                    .groupby("asset_type")["downtime_minutes"].mean())
    avoided = jobs["ml_probability"] * prevention_rate
    avoided_cost = float((avoided * jobs["asset_type"].map(C.UNPLANNED_FAILURE_COST_INR)).sum())
    planned_cost = float((jobs["duration_min"] / MINUTES_PER_HOUR * labour_rate_hr).sum())
    downtime_min = float((avoided * jobs["asset_type"].map(avg_downtime).fillna(0)).sum())
    net = avoided_cost - planned_cost
    return dict(failures_avoided=float(avoided.sum()), downtime_hours=downtime_min / MINUTES_PER_HOUR,
                avoided_cost=avoided_cost, planned_cost=planned_cost, net_saving=net,
                roi=net / planned_cost if planned_cost else 0.0)
