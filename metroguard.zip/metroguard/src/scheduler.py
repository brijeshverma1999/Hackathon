"""Greedy night-shift roster: highest priority first, assigned to the team free earliest."""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from . import config as C

MINUTES_PER_DAY = 24 * 60
ROSTER_COLUMNS = ["priority", "time_slot", "asset_id", "asset_type", "station", "risk_score",
                  "risk_category", "reason", "team", "duration_min", "recommended_action"]


@dataclass
class RosterConfig:
    window_start: str = C.DEFAULT_WINDOW_START
    window_end: str = C.DEFAULT_WINDOW_END
    teams: list[str] = field(default_factory=lambda: list(C.DEFAULT_TEAMS))
    min_risk: float = C.DEFAULT_MIN_RISK
    max_jobs: int = C.DEFAULT_MAX_JOBS
    buffer_min: int = C.TRANSFER_BUFFER_MIN


def _to_min(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def _fmt(minutes: int) -> str:
    minutes %= MINUTES_PER_DAY
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def window_minutes(cfg: RosterConfig) -> int:
    """Window length in minutes (handles overnight windows like 22:00-05:00)."""
    length = (_to_min(cfg.window_end) - _to_min(cfg.window_start)) % MINUTES_PER_DAY
    return length or MINUTES_PER_DAY


def build_roster(predictions: pd.DataFrame, cfg: RosterConfig | None = None
                 ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return (roster, deferred, team_utilisation).

    Candidates: risk_score >= cfg.min_risk, ordered by risk, criticality, overdue days,
    max severity, downtime (spec order); capped at cfg.max_jobs. Each job goes to the team
    free earliest; jobs that do not fit in the window are deferred to the next shift.
    `priority` is the risk rank (1 = most urgent); rows are shown in priority order.
    """
    cfg = cfg or RosterConfig()
    if not cfg.teams:
        raise ValueError("At least one technician team is required.")
    length = window_minutes(cfg)
    start = _to_min(cfg.window_start)
    cands = predictions[predictions["risk_score"] >= cfg.min_risk].sort_values(
        ["risk_score", "criticality", "maintenance_overdue_days", "max_severity_30d",
         "total_downtime_30d"], ascending=False, kind="mergesort").head(cfg.max_jobs)

    free_at = {t: 0 for t in cfg.teams}  # minutes from window start
    busy = {t: 0 for t in cfg.teams}
    jobs, deferred = [], []
    for rank, row in enumerate(cands.itertuples(), start=1):
        duration = int(row.estimated_maintenance_minutes)
        team = min(free_at, key=lambda t: (free_at[t], cfg.teams.index(t)))
        begin = free_at[team]
        if begin + duration > length:
            deferred.append(row)
            continue
        free_at[team] = begin + duration + cfg.buffer_min
        busy[team] += duration
        jobs.append(dict(
            priority=rank,
            time_slot=f"{_fmt(start + begin)}–{_fmt(start + begin + duration)}",
            asset_id=row.asset_id, asset_type=row.asset_type, station=row.station,
            risk_score=row.risk_score, risk_category=row.risk_category, reason=row.reason_text,
            team=team, duration_min=duration, recommended_action=row.recommended_action))
    roster = pd.DataFrame(jobs, columns=ROSTER_COLUMNS)
    deferred_df = pd.DataFrame(
        [dict(asset_id=r.asset_id, asset_type=r.asset_type, station=r.station,
              risk_score=r.risk_score, risk_category=r.risk_category,
              duration_min=int(r.estimated_maintenance_minutes)) for r in deferred],
        columns=["asset_id", "asset_type", "station", "risk_score", "risk_category", "duration_min"])
    util = pd.DataFrame({"team": list(busy), "busy_min": list(busy.values()),
                         "window_min": length})
    util["utilisation_pct"] = (100 * util["busy_min"] / length).round(0)
    util["jobs"] = [int((roster["team"] == t).sum()) for t in busy]
    return roster, deferred_df, util
