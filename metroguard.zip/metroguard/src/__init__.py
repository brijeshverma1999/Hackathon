"""MetroGuard: offline predictive maintenance prototype (synthetic data)."""
