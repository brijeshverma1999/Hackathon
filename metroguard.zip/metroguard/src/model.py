"""Model build / train / evaluate / save / load (RandomForest, scikit-learn only)."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import average_precision_score, precision_score, recall_score, roc_auc_score

from . import config as C

N_TREES = 300
MIN_LEAF = 10
MAX_DEPTH = 12


class ModelNotFoundError(Exception):
    """Raised when the trained model file is missing or unreadable."""


def build_model() -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=N_TREES, min_samples_leaf=MIN_LEAF, max_depth=MAX_DEPTH,
        n_jobs=-1, random_state=C.SEED)  # unweighted -> probabilities stay near the true base rate


def evaluate(model: RandomForestClassifier, X: pd.DataFrame, y: pd.Series) -> dict[str, float]:
    proba = model.predict_proba(X)[:, 1]
    pred = (proba >= C.PREDICTED_FAILURE_THRESHOLD).astype(int)
    return {
        "base_rate": float(y.mean()),
        "roc_auc": float(roc_auc_score(y, proba)),
        "avg_precision": float(average_precision_score(y, proba)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "mean_proba": float(proba.mean()),
    }


def save_bundle(model: RandomForestClassifier, medians: dict[str, float],
                metrics: dict[str, float], path: Path = C.MODEL_PATH) -> None:
    """Save model + everything needed for inference in a single joblib file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    importances = dict(zip(C.FEATURE_COLUMNS, map(float, model.feature_importances_)))
    joblib.dump({"model": model, "feature_columns": C.FEATURE_COLUMNS, "medians": medians,
                 "metrics": metrics, "importances": importances,
                 "trained_at": pd.Timestamp.now().isoformat(timespec="seconds")}, path)


def load_bundle(path: Path = C.MODEL_PATH) -> dict[str, Any]:
    """Load the saved bundle or raise ModelNotFoundError with the fix command."""
    if not Path(path).exists():
        raise ModelNotFoundError(f"Trained model not found at {path}. "
                                 "Train it with:  python scripts/train_model.py")
    try:
        bundle = joblib.load(path)
    except Exception as exc:
        raise ModelNotFoundError(f"Model file unreadable ({exc}). "
                                 "Re-train with:  python scripts/train_model.py") from exc
    if not {"model", "feature_columns", "medians"} <= set(bundle):
        raise ModelNotFoundError("Model file has an unexpected format. "
                                 "Re-train with:  python scripts/train_model.py")
    return bundle


def feature_medians(X: pd.DataFrame) -> dict[str, float]:
    return {c: float(np.nanmedian(X[c].to_numpy(dtype=float))) for c in X.columns}
