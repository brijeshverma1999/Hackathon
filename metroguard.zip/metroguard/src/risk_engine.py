"""Hybrid operational risk score (0-100).

risk = 100 * (0.70*ML + 0.10*criticality + 0.10*fault_trend + 0.10*maintenance_overdue)
Each component is normalised to 0-1:
  ML           = min(raw_probability / ML_PROB_SCALE, 1)
  criticality  = (criticality - 1) / 4
  fault_trend  = clip(fault_frequency_trend / TREND_SCALE, 0, 1)   (only increases count)
  overdue      = clip(maintenance_overdue_days / OVERDUE_SCALE_DAYS, 0, 1)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as C

MAX_CRITICALITY = 5
MIN_CRITICALITY = 1


def category_for(score: float) -> str:
    """Map a 0-100 score to CRITICAL/HIGH/MEDIUM/LOW/NORMAL."""
    for lower, name in C.RISK_BANDS:
        if score >= lower:
            return name
    return C.RISK_BANDS[-1][1]


def compute_risk(features: pd.DataFrame, ml_proba: np.ndarray) -> pd.DataFrame:
    """Return per-asset risk columns, indexed like `features`, sorted by priority."""
    ml = np.clip(ml_proba / C.ML_PROB_SCALE, 0, 1)
    crit = (features["criticality"] - MIN_CRITICALITY) / (MAX_CRITICALITY - MIN_CRITICALITY)
    trend = (features["fault_frequency_trend"] / C.TREND_SCALE).clip(0, 1)
    overdue = (features["maintenance_overdue_days"] / C.OVERDUE_SCALE_DAYS).clip(0, 1)

    out = pd.DataFrame(index=features.index)
    out["ml_probability"] = ml_proba
    out["predicted_failure"] = (ml_proba >= C.PREDICTED_FAILURE_THRESHOLD).astype(int)
    out["risk_score"] = (100 * (C.W_ML * ml + C.W_CRIT * crit
                                + C.W_TREND * trend + C.W_OVERDUE * overdue)).round(1)
    out["risk_category"] = out["risk_score"].map(category_for)
    # Priority: risk first, then criticality, overdue, severity, downtime (spec order)
    order = features.assign(_risk=out["risk_score"]).sort_values(
        ["_risk", "criticality", "maintenance_overdue_days", "max_severity_30d", "total_downtime_30d"],
        ascending=False, kind="mergesort").index
    rank = pd.Series(np.arange(1, len(order) + 1), index=order)
    out["priority"] = rank.reindex(out.index).astype(int)
    return out.sort_values("priority")
