"""Local data loading with validation. Reads SQLite first, falls back to bundled CSVs.

No network access of any kind.
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any

import pandas as pd

from . import config as C

REQUIRED_COLUMNS: dict[str, list[str]] = {
    "assets": ["asset_id", "asset_type", "station", "installation_date", "manufacturer",
               "criticality", "maintenance_interval_days", "estimated_maintenance_minutes"],
    "fault_logs": ["fault_id", "asset_id", "timestamp", "fault_type", "severity",
                   "downtime_minutes", "repair_minutes"],
    "maintenance_logs": ["maintenance_id", "asset_id", "maintenance_date", "maintenance_type",
                         "duration_minutes", "technician_id"],
}
CSV_PATHS = {"assets": C.ASSETS_CSV, "fault_logs": C.FAULTS_CSV, "maintenance_logs": C.MAINT_CSV}
NUMERIC_COLUMNS = {
    "assets": ["criticality", "maintenance_interval_days", "estimated_maintenance_minutes"],
    "fault_logs": ["severity", "downtime_minutes", "repair_minutes"],
    "maintenance_logs": ["duration_minutes"],
}
GENERATE_HINT = ("Run:  python scripts/generate_data.py  then  python scripts/initialize_db.py  "
                 "then  python scripts/train_model.py")


class DataError(Exception):
    """Raised for missing / empty / invalid local data, with an actionable message."""


def validate_columns(name: str, df: pd.DataFrame) -> None:
    """Raise DataError if required columns are missing or the table is empty."""
    missing = [c for c in REQUIRED_COLUMNS[name] if c not in df.columns]
    if missing:
        raise DataError(f"Table '{name}' is missing required column(s): {missing}.")
    if df.empty:
        raise DataError(f"Table '{name}' is empty. {GENERATE_HINT}")


def _read_csvs() -> dict[str, pd.DataFrame]:
    tables = {}
    for name, path in CSV_PATHS.items():
        if not path.exists():
            raise DataError(f"Missing data file: {path}. {GENERATE_HINT}")
        try:
            tables[name] = pd.read_csv(path)
        except Exception as exc:  # pandas raises several parser error types
            raise DataError(f"Could not read {path.name}: {exc}") from exc
    return tables


def _read_db() -> dict[str, pd.DataFrame]:
    if not C.DB_PATH.exists():
        raise DataError(f"Database not found: {C.DB_PATH}")
    try:
        with sqlite3.connect(C.DB_PATH) as conn:
            return {name: pd.read_sql_query(f"SELECT * FROM {name}", conn)
                    for name in CSV_PATHS}
    except (sqlite3.DatabaseError, pd.errors.DatabaseError) as exc:
        raise DataError(f"Local database unreadable or corrupt ({exc}).") from exc


def _clean(tables: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    """Validate, coerce types, drop invalid rows and orphan records."""
    for name, df in tables.items():
        validate_columns(name, df)
        for col in NUMERIC_COLUMNS[name]:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    assets = tables["assets"].dropna(subset=["asset_id", "asset_type", "criticality"]).copy()
    assets["installation_date"] = pd.to_datetime(assets["installation_date"], errors="coerce")
    assets = assets.dropna(subset=["installation_date"]).drop_duplicates("asset_id")
    assets["criticality"] = assets["criticality"].clip(1, 5).astype(int)
    assets["maintenance_interval_days"] = assets["maintenance_interval_days"].fillna(60)
    assets["estimated_maintenance_minutes"] = assets["estimated_maintenance_minutes"].fillna(45)

    faults = tables["fault_logs"].copy()
    faults["timestamp"] = pd.to_datetime(faults["timestamp"], errors="coerce")
    faults = faults.dropna(subset=["asset_id", "timestamp", "severity"])
    faults = faults[faults.asset_id.isin(assets.asset_id)]
    faults[["downtime_minutes", "repair_minutes"]] = faults[["downtime_minutes", "repair_minutes"]].fillna(0)

    maint = tables["maintenance_logs"].copy()
    maint["maintenance_date"] = pd.to_datetime(maint["maintenance_date"], errors="coerce")
    maint = maint.dropna(subset=["asset_id", "maintenance_date"])
    maint = maint[maint.asset_id.isin(assets.asset_id)]

    for name, df in (("assets", assets), ("fault_logs", faults), ("maintenance_logs", maint)):
        if df.empty:
            raise DataError(f"No valid rows left in '{name}' after cleaning.")
    return {"assets": assets.reset_index(drop=True),
            "fault_logs": faults.sort_values("timestamp").reset_index(drop=True),
            "maintenance_logs": maint.sort_values("maintenance_date").reset_index(drop=True)}


def _as_of(faults: pd.DataFrame, maint: pd.DataFrame) -> pd.Timestamp:
    """Reference 'today': from meta.json if present, else the day after the last record."""
    if C.META_JSON.exists():
        try:
            return pd.Timestamp(json.loads(C.META_JSON.read_text())["as_of"]).normalize()
        except (ValueError, KeyError, json.JSONDecodeError):
            pass
    last = max(faults["timestamp"].max(), maint["maintenance_date"].max())
    return (last.normalize() + pd.Timedelta(days=1))


def load_all(prefer_db: bool = True) -> dict[str, Any]:
    """Load, validate and clean all tables.

    Returns dict with keys: assets, faults, maint, as_of, source, warnings.
    """
    warnings: list[str] = []
    tables, source = None, "csv"
    if prefer_db and C.DB_PATH.exists():
        try:
            tables, source = _read_db(), "sqlite"
            for name, df in tables.items():
                validate_columns(name, df)
        except DataError as exc:
            warnings.append(f"{exc} Falling back to CSV files.")
            tables, source = None, "csv"
    if tables is None:
        tables = _read_csvs()
    tables = _clean(tables)
    return {"assets": tables["assets"], "faults": tables["fault_logs"],
            "maint": tables["maintenance_logs"],
            "as_of": _as_of(tables["fault_logs"], tables["maintenance_logs"]),
            "source": source, "warnings": warnings}


def save_roster(roster: pd.DataFrame, shift_date: str) -> bool:
    """Persist a generated roster to SQLite (best effort; returns success)."""
    try:
        with sqlite3.connect(C.DB_PATH) as conn:
            out = roster.copy()
            out.insert(0, "shift_date", shift_date)
            out.insert(1, "generated_at", pd.Timestamp.now().isoformat(timespec="seconds"))
            out.to_sql("roster_history", conn, if_exists="append", index=False)
        return True
    except Exception:  # DB is optional for the core flow
        return False
