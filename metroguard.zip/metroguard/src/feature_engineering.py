"""Feature engineering: turn raw logs into one feature row per asset, as of a date.

LEAKAGE RULE: every feature at snapshot time `t` uses only records strictly BEFORE `t`.
The training target uses records in [t, t + 7 days) and is never a feature.

Features (see config.FEATURE_COLUMNS)
-------------------------------------
asset_age_years              years since installation
fault_count_7d/30d/90d       faults in trailing window
average_downtime_30d         mean downtime (min) per fault, last 30d
total_downtime_30d           summed downtime (min), last 30d
max_severity_30d             worst fault severity (1-5), last 30d
average_repair_time_30d      mean repair time (min), last 30d
days_since_last_fault        capped at NEVER_DAYS if none
days_since_last_maintenance  capped at NEVER_DAYS if none
maintenance_overdue_days     max(0, days since maintenance - maintenance interval)
previous_failure_count       faults with severity >= FAILURE_MIN_SEVERITY in last 365d
fault_frequency_trend        faults in last 15d minus faults in the 15d before
downtime_trend               downtime (min) in last 15d minus the 15d before
criticality                  1-5 (from asset register)
maintenance_interval_days    planned interval (from asset register)
type_<AssetType>             one-hot encoding of asset type

Explanation-only columns (not model inputs): top_fault_type_30d, top_fault_count_30d.
"""
from __future__ import annotations

import pandas as pd

from . import config as C

CONTEXT_COLUMNS = ["asset_type", "station", "manufacturer", "estimated_maintenance_minutes"]
DAYS_PER_YEAR = 365.25


def compute_features(assets: pd.DataFrame, faults: pd.DataFrame, maint: pd.DataFrame,
                     as_of: pd.Timestamp) -> pd.DataFrame:
    """Compute features for every asset using only records before `as_of`.

    Returns a DataFrame indexed by asset_id: FEATURE_COLUMNS + explanation/context columns.
    """
    as_of = pd.Timestamp(as_of).normalize()
    base = assets.set_index("asset_id")
    idx = base.index

    f = faults.loc[faults["timestamp"] < as_of].copy()
    f["days_ago"] = (as_of - f["timestamp"]).dt.total_seconds() / 86400.0
    m = maint.loc[maint["maintenance_date"] < as_of]

    def window(lo: float, hi: float) -> pd.DataFrame:
        return f[(f["days_ago"] > lo) & (f["days_ago"] <= hi)]

    def count(lo: float, hi: float) -> pd.Series:
        return window(lo, hi).groupby("asset_id").size().reindex(idx).fillna(0.0)

    def total(col: str, lo: float, hi: float) -> pd.Series:
        return window(lo, hi).groupby("asset_id")[col].sum().reindex(idx).fillna(0.0)

    w30 = window(0, 30).groupby("asset_id")
    half = C.TREND_WINDOW_DAYS

    out = pd.DataFrame(index=idx)
    out["asset_age_years"] = ((as_of - base["installation_date"]).dt.days / DAYS_PER_YEAR).clip(lower=0)
    out["fault_count_7d"] = count(0, 7)
    out["fault_count_30d"] = count(0, 30)
    out["fault_count_90d"] = count(0, 90)
    out["average_downtime_30d"] = w30["downtime_minutes"].mean().reindex(idx).fillna(0.0)
    out["total_downtime_30d"] = w30["downtime_minutes"].sum().reindex(idx).fillna(0.0)
    out["max_severity_30d"] = w30["severity"].max().reindex(idx).fillna(0.0)
    out["average_repair_time_30d"] = w30["repair_minutes"].mean().reindex(idx).fillna(0.0)

    last_fault = f.groupby("asset_id")["days_ago"].min().reindex(idx)
    out["days_since_last_fault"] = last_fault.fillna(C.NEVER_DAYS).clip(upper=C.NEVER_DAYS)
    last_maint = m.groupby("asset_id")["maintenance_date"].max().reindex(idx)
    since_maint = (as_of - last_maint).dt.days
    out["days_since_last_maintenance"] = since_maint.fillna(C.NEVER_DAYS).clip(upper=C.NEVER_DAYS)
    out["maintenance_overdue_days"] = (
        out["days_since_last_maintenance"] - base["maintenance_interval_days"]).clip(lower=0)

    severe = f[(f["days_ago"] <= C.PREVIOUS_FAILURE_DAYS) & (f["severity"] >= C.FAILURE_MIN_SEVERITY)]
    out["previous_failure_count"] = severe.groupby("asset_id").size().reindex(idx).fillna(0.0)
    out["fault_frequency_trend"] = count(0, half) - count(half, 2 * half)
    out["downtime_trend"] = total("downtime_minutes", 0, half) - total("downtime_minutes", half, 2 * half)
    out["criticality"] = base["criticality"].astype(float)
    out["maintenance_interval_days"] = base["maintenance_interval_days"].astype(float)
    for asset_type in C.ASSET_TYPE_LEVELS:
        out[f"type_{asset_type}"] = (base["asset_type"] == asset_type).astype(int)

    # Explanation-only: dominant recent fault type
    per_type = (window(0, 30).groupby(["asset_id", "fault_type"]).size().rename("n").reset_index()
                .sort_values(["asset_id", "n", "fault_type"], ascending=[True, False, True])
                .drop_duplicates("asset_id").set_index("asset_id"))
    out["top_fault_type_30d"] = per_type["fault_type"].reindex(idx).fillna("")
    out["top_fault_count_30d"] = per_type["n"].reindex(idx).fillna(0).astype(int)

    out[C.FEATURE_COLUMNS] = out[C.FEATURE_COLUMNS].astype(float).fillna(0.0)
    return out.join(base[CONTEXT_COLUMNS])


def build_training_frame(assets: pd.DataFrame, faults: pd.DataFrame, maint: pd.DataFrame,
                         as_of: pd.Timestamp) -> pd.DataFrame:
    """Weekly snapshots per asset with label = failure within the next 7 days.

    Features come only from data before each snapshot; the label only from the 7 days after.
    """
    as_of = pd.Timestamp(as_of).normalize()
    data_start = min(faults["timestamp"].min(), maint["maintenance_date"].min()).normalize()
    horizon = pd.Timedelta(days=C.PREDICTION_HORIZON_DAYS)
    snapshots = pd.date_range(data_start + pd.Timedelta(days=C.WARMUP_DAYS), as_of - horizon,
                              freq=f"{C.SNAPSHOT_STEP_DAYS}D")
    failures = faults[faults["severity"] >= C.FAILURE_MIN_SEVERITY]
    frames = []
    for snap in snapshots:
        feats = compute_features(assets, faults, maint, snap)[C.FEATURE_COLUMNS]
        nxt = failures[(failures["timestamp"] >= snap) & (failures["timestamp"] < snap + horizon)]
        feats["target"] = feats.index.isin(nxt["asset_id"]).astype(int)
        feats["snapshot"] = snap
        frames.append(feats.reset_index())
    if not frames:
        raise ValueError("Not enough history to build training snapshots.")
    return pd.concat(frames, ignore_index=True)
