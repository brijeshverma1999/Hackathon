"""Prediction pipeline: features -> RandomForest probability -> hybrid risk -> explanations."""
from __future__ import annotations

from typing import Any

import pandas as pd

from .explanations import build_explanations
from .feature_engineering import compute_features
from .risk_engine import compute_risk


def predict_assets(data: dict[str, Any], bundle: dict[str, Any]) -> pd.DataFrame:
    """Score every asset as of `data['as_of']`.

    Returns one row per asset (sorted by priority) with identity, features, ML probability,
    risk score/category, priority, reasons, recommended action and operational impact.
    """
    feats = compute_features(data["assets"], data["faults"], data["maint"], data["as_of"])
    X = feats[bundle["feature_columns"]].fillna(pd.Series(bundle["medians"]))
    proba = bundle["model"].predict_proba(X)[:, 1]
    risk = compute_risk(feats, proba)
    result = risk.join(feats)
    result = result.join(build_explanations(result))
    result.index.name = "asset_id"
    return result.reset_index()
