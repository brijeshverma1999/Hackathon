"""Deterministic, template-based explanations (no LLM). Specific to each asset's numbers."""
from __future__ import annotations

import pandas as pd

# Thresholds
MIN_FAULTS_30D = 4
MIN_FAULTS_7D = 2
MIN_OVERDUE_DAYS = 1
HIGH_DOWNTIME_30D_MIN = 300
MIN_TREND = 2
MIN_DOWNTIME_TREND_MIN = 60
HIGH_CRITICALITY = 4
MIN_REPEAT_TYPE = 3
AGE_ABOVE_FLEET_YEARS = 1.0
MAX_REASONS = 6

ACTIONS = {
    "Motor": "Inspect motor, drive and related mechanical components.",
    "Brake": "Inspect brake assembly and braking sensors.",
    "Door": "Inspect door mechanism and door sensors.",
    "Electrical": "Inspect electrical supply, wiring and control unit.",
    "Sensor": "Inspect sensor alignment and sensor wiring.",
    "Communication": "Check communication links, network modules and connectors.",
    "CardReader": "Inspect card reader module, cabling and firmware status.",
    "Display": "Inspect display unit, backlight and display cabling.",
    "Mechanical": "Inspect moving parts, lubrication and wear points.",
    "Overheating": "Inspect cooling, ventilation and thermal protection.",
}
GENERIC_ACTION = "Perform a general inspection and preventive service."
IMPACT = {
    "Escalator": "Stoppage may force crowding on stairs and block passenger flow at {station}.",
    "Lift": "Outage removes the accessible route at {station} for elderly and disabled passengers.",
    "TicketGate": "Gate failure creates entry/exit queues at {station}.",
    "TicketMachine": "Machine failure reduces ticket-vending capacity at {station}.",
}


def recommended_action(top_fault_type: str) -> str:
    return ACTIONS.get(top_fault_type, GENERIC_ACTION)


def explain_row(row: pd.Series, fleet_avg_age: float) -> list[str]:
    """Return human-readable reasons for one asset (most important first)."""
    r: list[str] = []
    if row.fault_count_7d >= MIN_FAULTS_7D:
        r.append(f"{int(row.fault_count_7d)} faults occurred in the last 7 days")
    if row.fault_count_30d >= MIN_FAULTS_30D:
        r.append(f"{int(row.fault_count_30d)} faults occurred in the last 30 days")
    if row.fault_frequency_trend >= MIN_TREND:
        r.append(f"Fault frequency is increasing (+{int(row.fault_frequency_trend)} vs the previous 15 days)")
    if row.maintenance_overdue_days >= MIN_OVERDUE_DAYS:
        r.append(f"Maintenance is {int(row.maintenance_overdue_days)} days overdue")
    if row.total_downtime_30d >= HIGH_DOWNTIME_30D_MIN:
        r.append(f"High recent downtime: {int(row.total_downtime_30d)} min in the last 30 days")
    if row.downtime_trend >= MIN_DOWNTIME_TREND_MIN:
        r.append("Recent downtime is increasing")
    if row.top_fault_count_30d >= MIN_REPEAT_TYPE:
        r.append(f"Repeated {row.top_fault_type_30d} faults ({int(row.top_fault_count_30d)} in 30 days)")
    if row.criticality >= HIGH_CRITICALITY:
        r.append(f"Asset criticality is {int(row.criticality)}/5")
    if row.asset_age_years - fleet_avg_age >= AGE_ABOVE_FLEET_YEARS:
        r.append(f"Asset age ({row.asset_age_years:.1f} yrs) is above fleet average ({fleet_avg_age:.1f} yrs)")
    if not r:
        r.append("No significant risk indicators in recent history")
    return r[:MAX_REASONS]


def build_explanations(result: pd.DataFrame) -> pd.DataFrame:
    """Return reasons (list), reason_text (one line), recommended_action and impact columns."""
    fleet_avg_age = float(result["asset_age_years"].mean())
    reasons = result.apply(explain_row, axis=1, fleet_avg_age=fleet_avg_age)
    out = pd.DataFrame(index=result.index)
    out["reasons"] = reasons
    out["reason_text"] = reasons.map(lambda rs: "; ".join(rs[:3]))
    out["recommended_action"] = result["top_fault_type_30d"].map(recommended_action)
    out["impact"] = [IMPACT[t].format(station=s)
                     for t, s in zip(result["asset_type"], result["station"])]
    return out


def explanation_text(row: pd.Series) -> str:
    """Formatted multi-line explanation for display."""
    head = (f"{row['asset_id']} has predicted failure risk {row['risk_score']:.0f}/100 "
            f"({row['risk_category']}) because:")
    return head + "\n" + "\n".join(f"• {x}" for x in row["reasons"])
