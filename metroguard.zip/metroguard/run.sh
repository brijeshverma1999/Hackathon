#!/usr/bin/env bash
# One-command launcher for macOS / Linux:  bash run.sh
set -e
cd "$(dirname "$0")"

echo "=============================================="
echo "  METROGUARD - Predictive Maintenance"
echo "  Starting. The browser will open shortly."
echo "=============================================="

PYCMD=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c "import sys; sys.exit(sys.version_info < (3, 11))" 2>/dev/null; then
    PYCMD="$c"; break
  fi
done
if [ -z "$PYCMD" ]; then
  echo "Python 3.11 or newer was not found. Install it from https://www.python.org/downloads/"
  exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "[1/4] Creating local environment..."
  "$PYCMD" -m venv .venv
fi
VPY=".venv/bin/python"

if ! "$VPY" -c "import streamlit, pandas, numpy, sklearn, joblib, plotly" >/dev/null 2>&1; then
  echo "[2/4] Installing packages. Internet is needed only this once..."
  "$VPY" -m pip install --disable-pip-version-check -r requirements.txt
fi

if [ ! -f "data/fault_logs.csv" ]; then
  echo "[3/4] Generating synthetic data..."
  "$VPY" scripts/generate_data.py
fi
[ -f "database/metroguard.db" ] || "$VPY" scripts/initialize_db.py
if ! "$VPY" -c "from src.model import load_bundle; load_bundle()" >/dev/null 2>&1; then
  echo "[4/4] Training the model locally, about a minute..."
  "$VPY" scripts/train_model.py
fi

echo
echo "Running at http://localhost:8501   -   press Ctrl+C to stop."
exec "$VPY" -m streamlit run app.py
