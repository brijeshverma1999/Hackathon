"""METROGUARD - Predictive Maintenance & Night-Shift Planning (offline Streamlit app).

Run:  streamlit run app.py
All data (SYNTHETIC), the model and the database are local. No network calls are made.
"""
from __future__ import annotations

import html
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

from src import config as C
from src.data_loader import DataError, load_all, save_roster
from src.model import ModelNotFoundError, load_bundle
from src.predictor import predict_assets
from src.impact import estimate_impact
from src.scheduler import RosterConfig, build_roster, window_minutes

st.set_page_config(page_title="MetroGuard", page_icon="🚇", layout="wide")

PAGES = ["Dashboard", "Asset Risk", "Maintenance Roster", "Analytics", "Data", "About"]
CHART_H = 320
CSS = """
<style>
.block-container {padding-top: 1.6rem;}
.mg-title {font-size: 2rem; font-weight: 800; letter-spacing: .08em; margin: 0;}
.mg-sub {color: #57606a; margin-bottom: .6rem;}
.mg-badge {display:inline-block; padding:2px 10px; border-radius:12px; font-size:.78rem;
           background:#e7f6ec; color:#17803d; font-weight:600;}
.mg-demo {display:inline-block; padding:2px 10px; border-radius:12px; font-size:.78rem;
          background:#fff1d6; color:#9a5b00; font-weight:600; margin-left:6px;}
.mg-card {background:#f7f8fa; border:1px solid #e5e7eb; border-radius:10px; padding:14px 16px;}
.mg-card .v {font-size:1.8rem; font-weight:700; line-height:1.1;}
.mg-card .l {color:#57606a; font-size:.82rem; text-transform:uppercase; letter-spacing:.04em;}
.mg-note {background:#f7f8fa; border-left:4px solid #3b82d4; padding:8px 12px; border-radius:4px;
          font-size:.88rem; color:#1f2328;}
.mg-warn {background:#fff8e6; border-left:4px solid #e8a317; padding:8px 12px; border-radius:4px;
          font-size:.88rem;}
@media print {
  [data-testid="stSidebar"], header, .stButton, .stDownloadButton {display:none !important;}
}
</style>
"""


# ---------------------------------------------------------------- cached loaders
@st.cache_data(show_spinner="Loading local data ...")
def get_data() -> dict[str, Any]:
    return load_all()


@st.cache_resource(show_spinner="Loading local model ...")
def get_bundle() -> dict[str, Any]:
    return load_bundle()


@st.cache_data(show_spinner="Scoring assets locally ...")
def get_predictions() -> pd.DataFrame:
    return predict_assets(get_data(), get_bundle())


# ---------------------------------------------------------------- helpers
def kpi(label: str, value: Any) -> str:
    return f'<div class="mg-card"><div class="l">{html.escape(label)}</div><div class="v">{value}</div></div>'


def style_category(df: pd.DataFrame, col: str = "risk_category"):
    def color(v: str) -> str:
        return f"background-color: {C.CATEGORY_COLORS.get(v, '#fff')}; color: white; font-weight:600"
    return df.style.map(color, subset=[col])


def csv_bytes(df: pd.DataFrame) -> bytes:
    """CSV as UTF-8 with BOM so Excel on Windows displays characters like – correctly."""
    return df.to_csv(index=False).encode("utf-8-sig")


def header(demo: bool) -> None:
    badge = '<span class="mg-badge">● LOCAL / OFFLINE</span>'
    if demo:
        badge += '<span class="mg-demo">DEMO MODE · synthetic data</span>'
    st.markdown(f'<p class="mg-title">METROGUARD</p>'
                f'<p class="mg-sub">Predictive Maintenance &amp; Night-Shift Planning &nbsp; {badge}</p>',
                unsafe_allow_html=True)


# ---------------------------------------------------------------- pages
def page_dashboard(pred: pd.DataFrame, demo: bool) -> None:
    n = len(pred)
    cats = pred["risk_category"].value_counts()
    cols = st.columns(5)
    items = [("Assets Monitored", f"{n:,}"), ("High Risk Assets", int(cats.get("HIGH", 0))),
             ("Critical Assets", int(cats.get("CRITICAL", 0))),
             ("Predicted Failures", int(pred["predicted_failure"].sum())),
             ("Maintenance Overdue", int((pred["maintenance_overdue_days"] > 0).sum()))]
    for col, (label, val) in zip(cols, items):
        col.markdown(kpi(label, val), unsafe_allow_html=True)
    st.caption("Predicted failure risk for the coming 7 days. Decision support only — not a guarantee.")

    if demo:
        demo_df = pred[pred.asset_id.isin(C.DEMO_ASSETS)]
        st.markdown("**Demo spotlight** — assets with interesting history (scores come from the model):")
        st.dataframe(demo_df[["priority", "asset_id", "asset_type", "station", "risk_score",
                              "risk_category", "fault_count_7d", "fault_count_30d",
                              "maintenance_overdue_days"]], hide_index=True, width="stretch")

    c1, c2 = st.columns(2)
    dist = pred["risk_category"].value_counts().reindex(C.CATEGORY_ORDER).fillna(0).reset_index()
    dist.columns = ["Category", "Assets"]
    fig = px.bar(dist, x="Category", y="Assets", color="Category",
                 color_discrete_map=C.CATEGORY_COLORS, title="Risk distribution")
    fig.update_layout(showlegend=False, height=CHART_H, margin=dict(t=40, b=10))
    c1.plotly_chart(fig, width="stretch")

    by_type = pred.groupby(["asset_type", "risk_category"]).size().reset_index(name="Assets")
    fig = px.bar(by_type, x="asset_type", y="Assets", color="risk_category",
                 color_discrete_map=C.CATEGORY_COLORS, title="Risk by asset type",
                 category_orders={"risk_category": C.CATEGORY_ORDER})
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title=None, legend_title=None)
    c2.plotly_chart(fig, width="stretch")

    c3, c4 = st.columns(2)
    c3.markdown("**Top 10 high-risk assets**")
    top = pred.head(10)[["priority", "asset_id", "asset_type", "station", "risk_score", "risk_category"]]
    c3.dataframe(style_category(top), hide_index=True, width="stretch")
    st_df = (pred.groupby("station")
             .agg(avg_risk=("risk_score", "mean"),
                  high_or_critical=("risk_category", lambda s: int(s.isin(["HIGH", "CRITICAL"]).sum())))
             .sort_values("avg_risk", ascending=True).reset_index())
    fig = px.bar(st_df, x="avg_risk", y="station", orientation="h", color="high_or_critical",
                 color_continuous_scale="OrRd", title="Station-wise risk (avg score; colour = HIGH/CRITICAL count)")
    fig.update_layout(height=CHART_H + 60, margin=dict(t=40, b=10), xaxis_title=None, yaxis_title=None)
    c4.plotly_chart(fig, width="stretch")


def page_asset_risk(pred: pd.DataFrame, data: dict[str, Any]) -> None:
    st.subheader("Asset Risk")
    f1, f2, f3, f4 = st.columns(4)
    stations = f1.multiselect("Station", sorted(pred.station.unique()))
    types = f2.multiselect("Asset Type", sorted(pred.asset_type.unique()))
    cats = f3.multiselect("Risk Category", C.CATEGORY_ORDER)
    crits = f4.multiselect("Criticality", [1, 2, 3, 4, 5])
    view = pred
    if stations:
        view = view[view.station.isin(stations)]
    if types:
        view = view[view.asset_type.isin(types)]
    if cats:
        view = view[view.risk_category.isin(cats)]
    if crits:
        view = view[view.criticality.astype(int).isin(crits)]
    search = st.text_input("Search asset ID", placeholder="e.g. ESC-104").strip().upper()
    if search:
        view = view[view.asset_id.str.contains(search, regex=False)]
    if view.empty:
        st.info("No assets match the selected filters.")
        return

    table = view[["priority", "asset_id", "asset_type", "station", "risk_score", "risk_category",
                  "fault_count_7d", "fault_count_30d", "maintenance_overdue_days"]].rename(columns={
        "priority": "Priority", "asset_id": "Asset ID", "asset_type": "Type", "station": "Station",
        "risk_score": "Risk", "risk_category": "Category", "fault_count_7d": "Faults 7d",
        "fault_count_30d": "Faults 30d", "maintenance_overdue_days": "Maint. overdue (d)"})
    st.caption(f"{len(table):,} assets — select a row to see details.")
    event = st.dataframe(style_category(table, "Category"), hide_index=True, width="stretch",
                         height=320, on_select="rerun", selection_mode="single-row", key="asset_table")
    rows = event.selection.rows if event and event.selection else []
    default = C.DEMO_ASSETS[0] if C.DEMO_ASSETS[0] in set(view.asset_id) else view.iloc[0].asset_id
    asset_id = table.iloc[rows[0]]["Asset ID"] if rows else default
    asset_detail(pred[pred.asset_id == asset_id].iloc[0], data)


def asset_detail(row: pd.Series, data: dict[str, Any]) -> None:
    aid, as_of = row.asset_id, data["as_of"]
    st.markdown("---")
    st.markdown(f"### {aid} — {row.asset_type} @ {row.station}")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Final risk score", f"{row.risk_score:.0f}/100", row.risk_category, delta_color="off")
    c2.metric("ML failure probability (7d)", f"{row.ml_probability:.0%}")
    c3.metric("Priority rank", f"#{int(row.priority)}")
    c4.metric("Criticality", f"{int(row.criticality)}/5")
    left, right = st.columns([3, 2])
    with left:
        st.markdown(f"**Why predicted failure risk is {row.risk_category.lower()}:**")
        for reason in row.reasons:
            st.markdown(f"- {reason}")
        st.markdown("**Potential operational impact**")
        st.write(row.impact)
    with right:
        st.markdown("**Asset information**")
        a = data["assets"].set_index("asset_id").loc[aid]
        st.write(f"Manufacturer: {a.manufacturer}  \nInstalled: {a.installation_date:%d %b %Y} "
                 f"({row.asset_age_years:.1f} yrs)  \nMaintenance interval: {int(a.maintenance_interval_days)} days  \n"
                 f"Estimated maintenance: {int(a.estimated_maintenance_minutes)} min")
        st.markdown("**Recommended action**")
        st.info(row.recommended_action)
        st.caption(C.LABEL_PROTOTYPE)
    t1, t2 = st.tabs(["Recent faults", "Maintenance history"])
    faults = data["faults"]
    recent = faults[(faults.asset_id == aid) & (faults.timestamp < as_of)].tail(15).iloc[::-1]
    t1.dataframe(recent.drop(columns="asset_id"), hide_index=True, width="stretch")
    maint = data["maint"]
    hist = maint[(maint.asset_id == aid) & (maint.maintenance_date < as_of)].tail(10).iloc[::-1]
    t2.dataframe(hist.drop(columns="asset_id"), hide_index=True, width="stretch")


def render_impact(roster: pd.DataFrame, pred: pd.DataFrame, data: dict[str, Any]) -> None:
    """Estimated savings from acting on this roster (assumption-based, illustrative)."""
    st.markdown("#### Estimated impact of this roster")
    with st.expander("Assumptions (editable)"):
        a1, a2 = st.columns(2)
        prevention = a1.slider("Share of predicted failures avoided by a planned visit", 0.1, 1.0,
                               C.DEFAULT_PREVENTION_RATE, 0.05)
        labour = a2.number_input("Crew labour cost (₹ per hour)", 0, 20000, C.DEFAULT_LABOUR_RATE_INR_HR, 500)
        costs = pd.DataFrame({"Asset type": list(C.UNPLANNED_FAILURE_COST_INR),
                              "Assumed cost of one unplanned failure (₹)":
                                  list(C.UNPLANNED_FAILURE_COST_INR.values())})
        st.dataframe(costs, hide_index=True, width="stretch")
    imp = estimate_impact(roster, pred, data, prevention, float(labour))
    cols = st.columns(4)
    cols[0].markdown(kpi("Failures avoided (expected)", f"{imp['failures_avoided']:.1f}"), unsafe_allow_html=True)
    cols[1].markdown(kpi("Downtime avoided", f"{imp['downtime_hours']:.0f} h"), unsafe_allow_html=True)
    cols[2].markdown(kpi("Planned maintenance cost", f"₹{imp['planned_cost']:,.0f}"), unsafe_allow_html=True)
    cols[3].markdown(kpi("Estimated net saving", f"₹{imp['net_saving']:,.0f}"), unsafe_allow_html=True)
    st.caption("Illustrative estimate from assumed costs on synthetic data — not real metro figures. "
               "Expected failures avoided = ML probability × prevention share.")


def page_roster(pred: pd.DataFrame, data: dict[str, Any]) -> None:
    st.subheader("NIGHT SHIFT MAINTENANCE PLAN")
    with st.expander("Roster settings", expanded=False):
        c1, c2, c3, c4 = st.columns(4)
        w_start = c1.text_input("Window start (HH:MM)", C.DEFAULT_WINDOW_START)
        w_end = c2.text_input("Window end (HH:MM)", C.DEFAULT_WINDOW_END)
        min_risk = c3.slider("Minimum risk score", 0, 100, int(C.DEFAULT_MIN_RISK))
        max_jobs = c4.slider("Max jobs", 5, 100, C.DEFAULT_MAX_JOBS)
        teams = st.multiselect("Technician teams", ["Team A", "Team B", "Team C", "Team D", "Team E"],
                               default=C.DEFAULT_TEAMS)
    try:
        cfg = RosterConfig(w_start, w_end, teams, float(min_risk), int(max_jobs))
        window = window_minutes(cfg)
    except ValueError:
        st.error("Invalid window time. Use HH:MM, e.g. 22:00.")
        return
    if not teams:
        st.warning("Select at least one technician team.")
        return
    shift_date = (data["as_of"]).strftime("%A, %d %B %Y")
    st.markdown(f"**Date:** {shift_date} &nbsp;|&nbsp; **Window:** {w_start}–{w_end} "
                f"({window // 60}h {window % 60}m) &nbsp;|&nbsp; **Teams:** {', '.join(teams)}")

    if st.button("Generate Roster", type="primary") or "roster" not in st.session_state:
        roster, deferred, util = build_roster(pred, cfg)
        st.session_state.update(roster=roster, deferred=deferred, util=util)
        if st.session_state.get("_saved_for") != (shift_date, len(roster)):
            save_roster(roster.assign(), shift_date)
            st.session_state["_saved_for"] = (shift_date, len(roster))
    roster, deferred, util = (st.session_state[k] for k in ("roster", "deferred", "util"))
    if roster.empty:
        st.info("No assets meet the minimum risk score. Lower the threshold in Roster settings.")
        return

    cols = st.columns(len(util) + 1)
    cols[0].markdown(kpi("Jobs scheduled", len(roster)), unsafe_allow_html=True)
    for col, u in zip(cols[1:], util.itertuples()):
        col.markdown(kpi(f"{u.team} · {u.jobs} jobs", f"{int(u.utilisation_pct)}%"), unsafe_allow_html=True)

    show = roster.rename(columns={
        "priority": "Priority", "time_slot": "Time slot", "asset_id": "Asset ID", "asset_type": "Type",
        "station": "Station", "risk_score": "Risk", "risk_category": "Category", "reason": "Reason",
        "team": "Team", "duration_min": "Duration (min)", "recommended_action": "Recommended action"})
    st.dataframe(style_category(show, "Category"), hide_index=True, width="stretch",
                 height=min(700, 38 * (len(show) + 1)))
    st.caption(C.LABEL_PROTOTYPE)
    st.download_button("Download CSV", csv_bytes(roster.assign(shift_date=shift_date)),
                       file_name=f"night_roster_{data['as_of']:%Y%m%d}.csv", mime="text/csv")
    render_impact(roster, pred, data)
    if not deferred.empty:
        with st.expander(f"Deferred to next shift ({len(deferred)} assets did not fit the window)"):
            st.dataframe(deferred, hide_index=True, width="stretch")
    if st.toggle("Print-friendly view"):
        rows = "".join(
            f"<tr><td>{r.priority}</td><td>{r.time_slot}</td><td><b>{html.escape(r.asset_id)}</b></td>"
            f"<td>{html.escape(r.station)}</td><td>{r.risk_score:.0f}</td><td>{html.escape(r.team)}</td>"
            f"<td>{html.escape(r.recommended_action)}</td></tr>" for r in roster.itertuples())
        st.markdown(
            f"<h4>Night Shift Maintenance Plan — {shift_date}</h4>"
            f"<table style='width:100%;border-collapse:collapse' border='1' cellpadding='4'>"
            f"<tr><th>#</th><th>Time</th><th>Asset</th><th>Station</th><th>Risk</th><th>Team</th>"
            f"<th>Action</th></tr>{rows}</table><p><i>{C.LABEL_PROTOTYPE} Synthetic demo data.</i></p>",
            unsafe_allow_html=True)


def page_analytics(pred: pd.DataFrame, data: dict[str, Any]) -> None:
    st.subheader("Analytics")
    faults = data["faults"].merge(data["assets"][["asset_id", "asset_type", "station"]], on="asset_id")
    c1, c2 = st.columns(2)
    by_type = faults.groupby("asset_type").size().reset_index(name="Faults")
    fig = px.bar(by_type, x="asset_type", y="Faults", title="Faults by asset type")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title=None)
    c1.plotly_chart(fig, width="stretch")
    by_station = faults.groupby("station").size().sort_values().reset_index(name="Faults")
    fig = px.bar(by_station, x="Faults", y="station", orientation="h", title="Faults by station")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), yaxis_title=None)
    c2.plotly_chart(fig, width="stretch")

    c3, c4 = st.columns(2)
    monthly = faults.set_index("timestamp").groupby([pd.Grouper(freq="MS"), "asset_type"]).size()
    monthly = monthly.reset_index(name="Faults")
    fig = px.line(monthly, x="timestamp", y="Faults", color="asset_type", title="Fault trend (monthly)")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title=None, legend_title=None)
    c3.plotly_chart(fig, width="stretch")
    avg_dt = faults.groupby("asset_type")["downtime_minutes"].mean().round(1).reset_index()
    fig = px.bar(avg_dt, x="asset_type", y="downtime_minutes", title="Average downtime per fault (min)")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title=None)
    c4.plotly_chart(fig, width="stretch")

    c5, c6 = st.columns(2)
    over = pred[pred.maintenance_overdue_days > 0]
    fig = px.histogram(over, x="maintenance_overdue_days", nbins=20,
                       title=f"Maintenance overdue distribution ({len(over)} assets overdue)")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title="days overdue")
    c5.plotly_chart(fig, width="stretch")
    hi = pred[pred.risk_category.isin(["CRITICAL", "HIGH"])].groupby(["station", "asset_type"]).size()
    hi = hi.reset_index(name="Assets")
    fig = px.bar(hi, x="station", y="Assets", color="asset_type", title="High/Critical assets by station")
    fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), xaxis_title=None, legend_title=None)
    c6.plotly_chart(fig, width="stretch")


def page_data(data: dict[str, Any]) -> None:
    st.subheader("Data")
    st.markdown('<div class="mg-note">All data below is <b>synthetic</b>, generated locally for '
                'demonstration. It is not real Gujarat/Ahmedabad Metro data.</div>', unsafe_allow_html=True)
    st.caption(f"Loaded from: {data['source']} · reference date: {data['as_of']:%Y-%m-%d}")
    t1, t2, t3 = st.tabs(["Assets", "Fault Logs", "Maintenance Logs"])
    for tab, key, label in ((t1, "assets", "assets"), (t2, "faults", "fault_logs"),
                            (t3, "maint", "maintenance_logs")):
        with tab:
            df = data[key]
            st.caption(f"{len(df):,} rows")
            st.dataframe(df.head(1000), hide_index=True, width="stretch")
            st.download_button(f"Download {label}.csv", csv_bytes(df), file_name=f"{label}.csv",
                               mime="text/csv", key=f"dl_{key}")


def page_about(bundle: dict[str, Any]) -> None:
    st.subheader("About MetroGuard")
    st.markdown(
        "**Problem (PS-02 “Fix It Before It Breaks”)**: ticket gates, vending machines, lifts and "
        "escalators fail without warning, and maintenance is reactive.\n\n"
        "**Approach**: historical fault logs → features (counts, trends, downtime, overdue maintenance) → "
        "RandomForest estimates *predicted failure risk* for the next 7 days → a hybrid score "
        "(70% ML, 10% criticality, 10% fault trend, 10% maintenance overdue) → explainable reasons → "
        "a greedy night-shift roster.")
    st.markdown('<div class="mg-warn"><b>Synthetic data.</b> This prototype uses synthetic data because '
                'the hackathon does not provide operational metro datasets. It does not represent actual '
                'Gujarat Metro data.</div>', unsafe_allow_html=True)
    st.markdown("**Safety**: scores are predicted failure risk, not guarantees. "
                f"{C.LABEL_PROTOTYPE}")
    st.markdown("**Offline**: the model, database and data are local; no network request is made "
                "by the core workflow.")
    m = bundle.get("metrics", {})
    if m:
        st.markdown("**Model validation (time-held-out weeks)**")
        st.dataframe(pd.DataFrame([m]).round(3), hide_index=True, width="stretch")
    imp = bundle.get("importances")
    if imp:
        top = pd.Series(imp).sort_values().tail(10).reset_index()
        top.columns = ["feature", "importance"]
        fig = px.bar(top, x="importance", y="feature", orientation="h", title="Top feature importances")
        fig.update_layout(height=CHART_H, margin=dict(t=40, b=10), yaxis_title=None)
        st.plotly_chart(fig, width="stretch")


# ---------------------------------------------------------------- main
def main() -> None:
    st.markdown(CSS, unsafe_allow_html=True)
    with st.sidebar:
        st.markdown("### 🚇 METROGUARD")
        st.markdown('<span class="mg-badge">● LOCAL / OFFLINE</span>', unsafe_allow_html=True)
        st.caption("Core prediction engine running locally.")
        page = st.radio("Navigate", PAGES, label_visibility="collapsed")
        demo = st.toggle("Demo Mode", value=True, help="Highlight the planted demo assets.")
        st.caption("Synthetic demo data — not real metro data.")

    header(demo)
    try:
        data = get_data()
        bundle = get_bundle()
        pred = get_predictions()
    except DataError as exc:
        st.error(f"Data problem: {exc}")
        st.stop()
    except ModelNotFoundError as exc:
        st.error(str(exc))
        st.code("python scripts/train_model.py")
        st.stop()
    for w in data["warnings"]:
        st.warning(w)

    if page == "Dashboard":
        page_dashboard(pred, demo)
    elif page == "Asset Risk":
        page_asset_risk(pred, data)
    elif page == "Maintenance Roster":
        page_roster(pred, data)
    elif page == "Analytics":
        page_analytics(pred, data)
    elif page == "Data":
        page_data(data)
    else:
        page_about(bundle)


main()
