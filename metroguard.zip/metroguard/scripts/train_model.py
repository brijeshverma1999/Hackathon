"""Train the failure-prediction model from the local dataset.

Run:  python scripts/train_model.py
Validation is time-based: the final VALIDATION_FRACTION_DAYS of snapshots are held out.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config as C  # noqa: E402
from src import model as M  # noqa: E402
from src.data_loader import DataError, load_all  # noqa: E402
from src.feature_engineering import build_training_frame  # noqa: E402


def main() -> None:
    try:
        data = load_all(prefer_db=False)  # train straight from the CSVs
    except DataError as exc:
        raise SystemExit(f"ERROR: {exc}")
    print("Building weekly snapshots (features use only past data) ...")
    frame = build_training_frame(data["assets"], data["faults"], data["maint"], data["as_of"])
    print(f"  {len(frame)} rows | positive rate {frame.target.mean():.3f}")

    cutoff = frame.snapshot.max() - pd.Timedelta(days=C.VALIDATION_FRACTION_DAYS)
    # Gap of one horizon so training labels never overlap the validation period.
    gap_cut = cutoff - pd.Timedelta(days=C.PREDICTION_HORIZON_DAYS)
    train, valid = frame[frame.snapshot <= gap_cut], frame[frame.snapshot > cutoff]

    model = M.build_model().fit(train[C.FEATURE_COLUMNS], train.target)
    metrics = M.evaluate(model, valid[C.FEATURE_COLUMNS], valid.target)
    print("Validation (time-held-out, later weeks):")
    for k, v in metrics.items():
        print(f"  {k:>15}: {v:.3f}")

    final = M.build_model().fit(frame[C.FEATURE_COLUMNS], frame.target)  # refit on all history
    M.save_bundle(final, M.feature_medians(frame[C.FEATURE_COLUMNS]), metrics)
    print(f"Saved model -> {C.MODEL_PATH}")
    top = sorted(zip(C.FEATURE_COLUMNS, final.feature_importances_), key=lambda t: -t[1])[:6]
    print("Top features:", ", ".join(f"{n} ({v:.2f})" for n, v in top))


if __name__ == "__main__":
    main()
