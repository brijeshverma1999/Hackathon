"""Exercise error paths: missing model, corrupt DB (CSV fallback), missing CSV. Files are restored."""
from __future__ import annotations

import gc
import shutil
import sys
from pathlib import Path

import streamlit as st
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
MODEL = ROOT / "model" / "failure_model.pkl"
DB = ROOT / "database" / "metroguard.db"
CSV = ROOT / "data" / "assets.csv"


def run() -> AppTest:
    st.cache_data.clear()
    st.cache_resource.clear()
    gc.collect()
    return AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()


def case(name: str, targets: list[Path], mutate) -> None:
    backups = {t: t.with_suffix(t.suffix + ".bak") for t in targets}
    for t, b in backups.items():
        shutil.copy2(t, b)
    try:
        for t in targets:
            mutate(t)
        at = run()
        msgs = [e.value for e in at.error] + [w.value for w in at.warning]
        print(f"[{name}] exceptions={len(at.exception)} messages={[m[:120] for m in msgs]}"
              f" code={[c.value for c in at.code]}")
    finally:
        gc.collect()
        for t, b in backups.items():
            shutil.copy2(b, t)
            b.unlink()


def main() -> None:
    case("baseline", [CSV], lambda p: None)
    case("missing model", [MODEL], lambda p: p.unlink())
    case("corrupt db -> csv fallback", [DB], lambda p: p.write_bytes(b"not a sqlite database" * 50))
    case("missing csv, db ok", [CSV], lambda p: p.unlink())
    case("missing csv + corrupt db", [CSV, DB],
         lambda p: p.unlink() if p.suffix == ".csv" else p.write_bytes(b"garbage" * 100))
    case("assets.csv missing column", [CSV, DB],
         lambda p: p.write_text("asset_id,asset_type\nA-1,Lift\n") if p.suffix == ".csv"
         else p.write_bytes(b"garbage" * 100))
    print("restored:", MODEL.exists(), DB.exists(), CSV.exists())


if __name__ == "__main__":
    sys.exit(main())
