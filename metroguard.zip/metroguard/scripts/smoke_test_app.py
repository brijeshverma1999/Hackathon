"""Headless smoke test of every Streamlit page (no browser, no network)."""
from __future__ import annotations

import sys
from pathlib import Path

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
PAGES = ["Dashboard", "Asset Risk", "Maintenance Roster", "Analytics", "Data", "About"]


def main() -> int:
    failures = 0
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()
    for page in PAGES:
        at.sidebar.radio[0].set_value(page).run()
        status = "OK " if not at.exception else "FAIL"
        failures += bool(at.exception)
        print(f"{status} {page}: errors={len(at.error)} exceptions={[str(e.value) for e in at.exception]}")
    at.sidebar.radio[0].set_value("Maintenance Roster").run()
    clicked = [b for b in at.button if b.label == "Generate Roster"]
    if clicked:
        clicked[0].click().run()
        print("Generate Roster:", "FAIL" if at.exception else "OK")
        failures += bool(at.exception)
    return failures


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
