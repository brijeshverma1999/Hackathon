"""Quick sanity check of the scored fleet (distribution, demo assets, roster)."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config as C  # noqa: E402
from src.data_loader import load_all  # noqa: E402
from src.model import load_bundle  # noqa: E402
from src.predictor import predict_assets  # noqa: E402
from src.scheduler import build_roster  # noqa: E402

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 20)

bundle = load_bundle()
print("metrics:", {k: round(v, 3) for k, v in bundle["metrics"].items()})
pred = predict_assets(load_all(), bundle)
print("categories:", pred.risk_category.value_counts().reindex(C.CATEGORY_ORDER).fillna(0).astype(int).to_dict())
print("predicted failures:", int(pred.predicted_failure.sum()),
      "| overdue:", int((pred.maintenance_overdue_days > 0).sum()))
cols = ["priority", "asset_id", "station", "ml_probability", "risk_score", "risk_category",
        "fault_count_7d", "fault_count_30d", "maintenance_overdue_days"]
print(pred[pred.asset_id.isin(C.DEMO_ASSETS)][cols].to_string(index=False))
print(pred.head(10)[cols].to_string(index=False))
roster, deferred, util = build_roster(pred)
print(roster[["priority", "time_slot", "asset_id", "risk_score", "team", "duration_min"]].head(12).to_string(index=False))
print("jobs:", len(roster), "| deferred:", len(deferred))
print(util.to_string(index=False))
