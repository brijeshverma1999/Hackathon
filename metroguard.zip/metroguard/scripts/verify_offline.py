"""Prove the core workflow makes no outbound network connection.

Patches socket.connect to raise for any non-loopback address, then loads data, scores assets,
builds a roster and runs the full app headlessly.
"""
from __future__ import annotations

import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

attempts: list[object] = []
_real_connect = socket.socket.connect


def guarded_connect(self, address):  # type: ignore[no-untyped-def]
    host = address[0] if isinstance(address, tuple) else address
    if host not in ("127.0.0.1", "::1", "localhost"):
        attempts.append(address)
        raise OSError(f"Blocked outbound connection to {address}")
    return _real_connect(self, address)


socket.socket.connect = guarded_connect  # type: ignore[method-assign]

from streamlit.testing.v1 import AppTest  # noqa: E402

from src.data_loader import load_all  # noqa: E402
from src.model import load_bundle  # noqa: E402
from src.predictor import predict_assets  # noqa: E402
from src.scheduler import build_roster  # noqa: E402

pred = predict_assets(load_all(), load_bundle())
roster, _, _ = build_roster(pred)
at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()
for page in ["Dashboard", "Asset Risk", "Maintenance Roster", "Analytics", "Data", "About"]:
    at.sidebar.radio[0].set_value(page).run()
print(f"scored={len(pred)} roster_jobs={len(roster)} app_exceptions={len(at.exception)}")
print("outbound connection attempts:", attempts)
sys.exit(1 if attempts or at.exception else 0)
