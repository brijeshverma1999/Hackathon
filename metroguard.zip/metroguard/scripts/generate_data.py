"""Generate deterministic SYNTHETIC metro maintenance data for the MetroGuard demo.

The data is entirely synthetic and is NOT real Ahmedabad/Gujarat Metro data.

Failure patterns built in (so a model can learn them):
  * older assets fault more
  * per-asset hidden "frailty"
  * stable / gradually-deteriorating / suddenly-deteriorating episodes
  * self-exciting faults (recent faults raise the next-fault rate)
  * overdue preventive maintenance raises the fault rate
Three demo assets (ESC-104, LIFT-027, AFC-381) get episode/maintenance overrides only;
their risk scores always come from the real model.

Run:  python scripts/generate_data.py
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config as C  # noqa: E402

DAILY_RATE_CAP = 1.0
EXCITE_DECAY = 0.93
EXCITE_COEF = 0.4
EXCITE_CAP = 3.0
AGE_COEF = 0.06
OVERDUE_COEF = 0.03
OVERDUE_MULT_CAP = 2.5
HOT_MULTIPLIER = 2.5  # episode multiplier above which faults skew severe
BASE_RATE = {"Escalator": 0.024, "Lift": 0.020, "TicketGate": 0.022, "TicketMachine": 0.020}
SEVERITY_P = np.array([0.30, 0.28, 0.20, 0.14, 0.08])
SEVERITY_P_HOT = np.array([0.10, 0.18, 0.27, 0.27, 0.18])
CORRECTIVE_PROB = 0.55
DOMINANT_FAULT_PROB = 0.55
NEGLECT_PROB = 0.15
BUSY_STATIONS = {"Motera": 5, "Stadium": 5, "Vastrapur": 4, "Gujarat University": 4,
                 "Sabarmati": 4}

# Demo overrides.
# episode = (kind, start_days_before_end, ramp_days, hold_days, peak_multiplier)
# maint_gap_before_end = no preventive/corrective service in the last N days (overdue)
DEMO_OVERRIDES = {
    "ESC-104": dict(episode=("gradual", 110, 100, 100, 6.0), frailty=1.6, criticality=5,
                    age_start=8.5, dominant="Brake", maint_gap_before_end=75),
    "LIFT-027": dict(episode=("sudden", 12, 1, 100, 9.0), frailty=1.3, criticality=5,
                     age_start=7.0, dominant="Door", maint_gap_before_end=62),
    "AFC-381": dict(episode=("gradual", 70, 40, 100, 4.0), frailty=2.0, criticality=4,
                    age_start=6.0, dominant="Sensor", maint_gap_before_end=95),
}


def _build_assets(rng: np.random.Generator) -> pd.DataFrame:
    """Create the asset register."""
    rows = []
    start = pd.Timestamp(C.START_DATE)
    for asset_type, (prefix, count, interval, mins, _faults) in C.ASSET_TYPES.items():
        for n in range(1, count + 1):
            asset_id = f"{prefix}-{n:03d}"
            station = C.STATIONS[rng.integers(len(C.STATIONS))]
            base_crit = BUSY_STATIONS.get(station, 3)
            crit = int(np.clip(base_crit + rng.integers(-2, 2), 1, 5))
            if asset_type in ("Escalator", "Lift"):
                crit = int(min(5, crit + rng.integers(0, 2)))
            age_start = float(rng.uniform(0.3, 10.0))
            rows.append(dict(
                asset_id=asset_id, asset_type=asset_type, station=station,
                installation_date=(start - pd.Timedelta(days=int(age_start * 365))).date(),
                manufacturer=C.MANUFACTURERS[rng.integers(len(C.MANUFACTURERS))],
                criticality=crit, maintenance_interval_days=interval,
                estimated_maintenance_minutes=int(round(rng.integers(mins[0], mins[1] + 1) / 5) * 5),
            ))
    assets = pd.DataFrame(rows)
    for aid, ov in DEMO_OVERRIDES.items():
        i = assets.index[assets.asset_id == aid][0]
        assets.loc[i, "criticality"] = ov["criticality"]
        assets.loc[i, "installation_date"] = (
            start - pd.Timedelta(days=int(ov["age_start"] * 365))).date()
    return assets


def _episode_multiplier(days: np.ndarray, start: int, ramp: int, hold: int, peak: float) -> np.ndarray:
    """Ramp up linearly over `ramp` days, hold, then drop back to baseline."""
    t = days - start
    env = np.where(t < 0, 0.0,
                   np.where(t < ramp, t / max(ramp, 1), np.where(t < ramp + hold, 1.0, 0.0)))
    return peak * env


def _multiplier_matrix(rng: np.random.Generator, assets: pd.DataFrame, days: np.ndarray) -> np.ndarray:
    """Per-asset deterioration multiplier over time (stable / gradual / sudden episodes)."""
    D = len(days)
    mult = np.ones((len(assets), D))
    for i, aid in enumerate(assets.asset_id):
        kind = rng.choice(["stable", "gradual", "sudden"], p=[0.60, 0.28, 0.12])
        if kind == "gradual":
            for _ in range(rng.integers(1, 3)):
                mult[i] += _episode_multiplier(days, int(rng.integers(0, D - 30)),
                                               int(rng.integers(60, 200)),
                                               int(rng.integers(15, 50)), float(rng.uniform(2, 5)))
        elif kind == "sudden":
            for _ in range(rng.integers(1, 3)):
                mult[i] += _episode_multiplier(days, int(rng.integers(30, D - 3)), 1,
                                               int(rng.integers(10, 30)), float(rng.uniform(4, 9)))
        if aid in DEMO_OVERRIDES:
            _, s, r, h, p = DEMO_OVERRIDES[aid]["episode"]
            mult[i] = 1 + _episode_multiplier(days, D - s, r, h, p)
    return mult


def _preventive_schedule(rng: np.random.Generator, assets: pd.DataFrame, D: int) -> list[tuple[int, int]]:
    """Return (asset_index, day) preventive visits; neglected assets are serviced late."""
    visits: list[tuple[int, int]] = []
    for i, row in enumerate(assets.itertuples()):
        interval = int(row.maintenance_interval_days)
        neglected = rng.random() < NEGLECT_PROB
        cutoff = D + 1
        if row.asset_id in DEMO_OVERRIDES:
            cutoff = D - DEMO_OVERRIDES[row.asset_id]["maint_gap_before_end"]
            neglected = False
        t = int(rng.integers(0, interval))
        while t < D:
            if t <= cutoff:
                visits.append((i, t))
            delay = int(rng.integers(8, 35)) if neglected else int(rng.integers(-2, 5))
            step = max(7, interval + delay)
            if neglected and rng.random() < 0.2:
                step += interval
            t += step
    return visits


def generate() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Simulate day-by-day faults and maintenance. Returns (assets, faults, maintenance)."""
    rng = np.random.default_rng(C.SEED)
    D = C.HISTORY_DAYS
    start = pd.Timestamp(C.START_DATE)
    days = np.arange(D)

    assets = _build_assets(rng)
    N = len(assets)
    interval = assets.maintenance_interval_days.to_numpy()
    age_start = ((start - pd.to_datetime(assets.installation_date)).dt.days / 365.0).to_numpy()
    base = assets.asset_type.map(BASE_RATE).to_numpy()
    frailty = np.exp(rng.normal(-0.125, 0.5, N))
    dominant: list[str] = []
    for row in assets.itertuples():
        if row.asset_id in DEMO_OVERRIDES:
            frailty[row.Index] = DEMO_OVERRIDES[row.asset_id]["frailty"]
            dominant.append(DEMO_OVERRIDES[row.asset_id]["dominant"])
        else:
            types = C.ASSET_TYPES[row.asset_type][4]
            dominant.append(types[rng.integers(len(types))])
    fault_types = [C.ASSET_TYPES[t][4] for t in assets.asset_type]
    cutoff = np.full(N, D + 1)
    for i, aid in enumerate(assets.asset_id):
        if aid in DEMO_OVERRIDES:
            cutoff[i] = D - DEMO_OVERRIDES[aid]["maint_gap_before_end"]

    mult = _multiplier_matrix(rng, assets, days)
    prev_visits = _preventive_schedule(rng, assets, D)
    prev_by_day: dict[int, list[int]] = defaultdict(list)
    for i, d in prev_visits:
        prev_by_day[d].append(i)

    last_maint = np.array([-float(rng.integers(0, interval[i])) for i in range(N)])
    excite = np.zeros(N)
    pending: dict[int, list[tuple[int, float]]] = defaultdict(list)

    faults, corrective = [], []
    for d in range(D):
        for i in prev_by_day.get(d, []):
            last_maint[i] = d
        for i, dur in pending.pop(d, []):
            last_maint[i] = d
            corrective.append((i, d, dur))
        overdue = np.maximum(0.0, d - last_maint - interval)
        over_mult = np.minimum(1 + OVERDUE_COEF * overdue, OVERDUE_MULT_CAP)
        age_mult = np.exp(AGE_COEF * (age_start + d / 365.0 - 5.0))
        rate = (base * age_mult * frailty * mult[:, d] * over_mult
                * (1 + EXCITE_COEF * np.minimum(excite, EXCITE_CAP)))
        counts = rng.poisson(np.minimum(rate, DAILY_RATE_CAP))
        excite = excite * EXCITE_DECAY + counts
        for i in np.nonzero(counts)[0]:
            for _ in range(int(counts[i])):
                hot = mult[i, d] > HOT_MULTIPLIER
                sev = int(rng.choice(5, p=SEVERITY_P_HOT if hot else SEVERITY_P)) + 1
                ftypes = fault_types[i]
                ftype = (dominant[i] if rng.random() < DOMINANT_FAULT_PROB
                         else ftypes[rng.integers(len(ftypes))])
                repair = float(rng.lognormal(np.log(12 * sev), 0.4))
                downtime = repair + float(rng.uniform(5, 30)) * sev / 2
                ts = start + pd.Timedelta(days=d, seconds=int(rng.integers(0, 86400)))
                faults.append((i, ts, ftype, sev, int(round(downtime)), int(round(repair))))
                if (sev >= C.HIGH_SEVERITY and d + 1 < D and d + 1 <= cutoff[i]
                        and rng.random() < CORRECTIVE_PROB):
                    pending[d + 1].append((i, repair * float(rng.uniform(1.0, 1.5))))

    faults_df = pd.DataFrame(faults, columns=["i", "timestamp", "fault_type", "severity",
                                              "downtime_minutes", "repair_minutes"])
    faults_df["asset_id"] = assets.asset_id.to_numpy()[faults_df.i.to_numpy()]
    faults_df = faults_df.sort_values("timestamp").reset_index(drop=True)
    faults_df["fault_id"] = [f"F{n:06d}" for n in range(1, len(faults_df) + 1)]
    faults_df = faults_df[["fault_id", "asset_id", "timestamp", "fault_type", "severity",
                           "downtime_minutes", "repair_minutes"]]

    est = assets.estimated_maintenance_minutes.to_numpy()
    m_rows = []
    for i, d in prev_visits:
        mtype = "Inspection" if rng.random() < 0.15 else "Preventive"
        m_rows.append((i, d, mtype, int(round(est[i] * rng.uniform(0.8, 1.3)))))
    for i, d, dur in corrective:
        m_rows.append((i, d, "Corrective", int(round(max(dur, 15)))))
    maint = pd.DataFrame(m_rows, columns=["i", "day", "maintenance_type", "duration_minutes"])
    maint["asset_id"] = assets.asset_id.to_numpy()[maint.i.to_numpy()]
    maint["maintenance_date"] = (start + pd.to_timedelta(maint.day, unit="D")).dt.date
    maint["technician_id"] = [f"TECH-{rng.integers(1, C.TECHNICIAN_COUNT + 1):02d}"
                              for _ in range(len(maint))]
    maint = maint.sort_values(["maintenance_date", "asset_id"]).reset_index(drop=True)
    maint["maintenance_id"] = [f"M{n:06d}" for n in range(1, len(maint) + 1)]
    maint = maint[["maintenance_id", "asset_id", "maintenance_date", "maintenance_type",
                   "duration_minutes", "technician_id"]]
    return assets, faults_df, maint


def main() -> None:
    assets, faults, maint = generate()
    C.DATA_DIR.mkdir(parents=True, exist_ok=True)
    assets.to_csv(C.ASSETS_CSV, index=False)
    faults.to_csv(C.FAULTS_CSV, index=False)
    maint.to_csv(C.MAINT_CSV, index=False)
    as_of = (pd.Timestamp(C.START_DATE) + pd.Timedelta(days=C.HISTORY_DAYS)).date().isoformat()
    C.META_JSON.write_text(json.dumps(
        {"as_of": as_of, "seed": C.SEED, "synthetic": True,
         "note": "Synthetic demo data - not real metro data."}, indent=2))
    print(f"assets: {len(assets)} | faults: {len(faults)} | maintenance: {len(maint)} | as_of: {as_of}")
    print(assets.asset_type.value_counts().to_dict())
    assert 500 <= len(assets) <= 1500, "asset count out of range"
    assert len(faults) >= 20000, "need >= 20,000 fault records"
    assert len(maint) >= 5000, "need >= 5,000 maintenance records"


if __name__ == "__main__":
    main()
