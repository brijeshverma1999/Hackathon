"""Build the local SQLite database from the bundled CSV files.

Run:  python scripts/initialize_db.py
"""
from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config as C  # noqa: E402
from src.data_loader import CSV_PATHS, DataError, validate_columns  # noqa: E402


def main() -> None:
    C.DB_DIR.mkdir(parents=True, exist_ok=True)
    tables = {}
    for name, path in CSV_PATHS.items():
        if not path.exists():
            raise SystemExit(f"Missing {path}. Run: python scripts/generate_data.py")
        df = pd.read_csv(path)
        try:
            validate_columns(name, df)
        except DataError as exc:
            raise SystemExit(str(exc))
        tables[name] = df
    if C.DB_PATH.exists():
        C.DB_PATH.unlink()
    with sqlite3.connect(C.DB_PATH) as conn:
        for name, df in tables.items():
            df.to_sql(name, conn, index=False)
            conn.execute(f"CREATE INDEX idx_{name}_asset ON {name}(asset_id)")
        conn.execute("""CREATE TABLE roster_history (
            shift_date TEXT, generated_at TEXT, priority INTEGER, time_slot TEXT,
            asset_id TEXT, asset_type TEXT, station TEXT, risk_score REAL,
            risk_category TEXT, reason TEXT, team TEXT, duration_min INTEGER,
            recommended_action TEXT)""")
    print(f"Database created at {C.DB_PATH}: " + ", ".join(f"{n}={len(d)}" for n, d in tables.items()))


if __name__ == "__main__":
    main()
