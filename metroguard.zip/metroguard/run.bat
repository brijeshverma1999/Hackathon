@echo off
setlocal
cd /d "%~dp0"
title MetroGuard
echo ==============================================
echo   METROGUARD - Predictive Maintenance
echo   Starting. The browser will open shortly.
echo ==============================================
echo.

rem --- 1. Find Python 3.11+ -------------------------------------------------
set "PYCMD="
python -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
if not errorlevel 1 set "PYCMD=python"
if not defined PYCMD (
  py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3"
)
if not defined PYCMD (
  echo Python 3.11 or newer was not found.
  echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH", then run this again.
  pause
  exit /b 1
)

rem --- 2. Private virtual environment ---------------------------------------
if not exist ".venv\Scripts\python.exe" (
  echo [1/4] Creating local environment...
  %PYCMD% -m venv .venv
  if errorlevel 1 (
    echo Could not create the environment.
    pause
    exit /b 1
  )
)
set "VPY=.venv\Scripts\python.exe"

rem --- 3. Packages - internet is needed only for this first install ---------
"%VPY%" -c "import streamlit, pandas, numpy, sklearn, joblib, plotly" >nul 2>&1
if errorlevel 1 (
  echo [2/4] Installing packages. Internet is needed only this once...
  "%VPY%" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo Package install failed. Check your internet connection and run this again.
    pause
    exit /b 1
  )
)

rem --- 4. Data, database and model - rebuilt only if missing or unreadable ---
if not exist "data\fault_logs.csv" (
  echo [3/4] Generating synthetic data...
  "%VPY%" scripts\generate_data.py
)
if not exist "database\metroguard.db" "%VPY%" scripts\initialize_db.py
"%VPY%" -c "from src.model import load_bundle; load_bundle()" >nul 2>&1
if errorlevel 1 (
  echo [4/4] Training the model locally, about a minute...
  "%VPY%" scripts\train_model.py
  if errorlevel 1 (
    echo Model training failed.
    pause
    exit /b 1
  )
)

rem --- 5. Launch -------------------------------------------------------------
echo.
echo Running at http://localhost:8501   -   close this window to stop.
echo.
"%VPY%" -m streamlit run app.py
pause
